#' Palette and theme data
#'
#' The \code{ggthemes} environment contains various values used in
#' themes and palettes. This is undocumented and subject to change.
#'
#' @format A \code{list} object.
"ggthemes_data"
