library("testthat")
test_check("hoardr")
