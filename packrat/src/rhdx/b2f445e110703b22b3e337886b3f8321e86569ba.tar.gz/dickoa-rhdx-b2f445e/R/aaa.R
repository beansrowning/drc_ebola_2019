## Set up pkg environment to store HDX configuration object
.rhdx_env <- new.env(parent = emptyenv())
