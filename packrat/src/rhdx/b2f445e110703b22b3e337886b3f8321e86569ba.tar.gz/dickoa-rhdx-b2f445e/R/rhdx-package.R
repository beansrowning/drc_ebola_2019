##' rhdx
##'
##' R client for the Humanitarian Data Exchange platform
##'
##' @name rhdx
##' @aliases rhdx-package
##' @docType package
##' @author \email{mail@ahmadoudicko.com}
##' @keywords package
NULL

