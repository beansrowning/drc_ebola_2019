# CRAN comments

I have read and agree to the the CRAN policies at
http://cran.r-project.org/web/packages/policies.html

## Test environments
* local Windows 10 x64, R 3.5.2
* local Linux 4.20.5-arch1-1-ARCH, R 3.5.2

## R CMD check results
There were no ERRORs or WARNINGs.

## Downstream dependencies
There are no downstream dependencies.

Thanks!
Ahmadou Dicko
