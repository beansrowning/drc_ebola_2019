library(testthat)
library(rhdx)

test_check("rhdx")
