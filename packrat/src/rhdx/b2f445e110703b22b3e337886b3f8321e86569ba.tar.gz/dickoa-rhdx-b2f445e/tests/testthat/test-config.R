context("configuration")

test_that("Configuration with global config list", {
  skip_on_cran()
})

test_that("Configuration with global config yaml", {
  skip_on_cran()
})

test_that("Configuration with global config json", {
  skip_on_cran()
})
